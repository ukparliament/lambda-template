def handler(event, context):
    print(f"event={event}")
    return 'Hello world'